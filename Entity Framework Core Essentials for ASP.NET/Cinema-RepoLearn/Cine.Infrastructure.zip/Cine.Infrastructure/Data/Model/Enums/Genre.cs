﻿namespace Cinema_RepoLearn.Infrastructure.Data.Model.Enums
{
    public enum Genre
    {
        NotClassified,
        Action,
        Comedy,
        Drama,
        Thriller,
        SciFi,
        Fantasy,
        Horror
    }
}
