﻿namespace TravelAgency.Data
{
    public static class DataConstraints
    {
        // Customer
        public const byte CustomerFullNameMinLenght = 4;
        public const byte CustomerFullNameMaxLenght = 60;
        public const byte CustomerEmailMinLenght = 6;
        public const byte CustomerEmailMaxLenght = 50;
        public const byte CustomerPhoneNumberMaxLenght = 13;

        // Guide
        public const byte GuideFullNameMinLenght = 4;
        public const byte GuideFullNameMaxLenght = 60;

        // TourPackage
        public const byte TourPackageNameMinLenght = 2;
        public const byte TourPackageNameMaxLenght = 40;
        public const byte TourPackageDescriptionMaxLenght = 200;
    }
}
